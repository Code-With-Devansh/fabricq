import { createJobService } from "../services/httpJob.js";
import { createJobSchema } from "../validators/http_job.js";

export const uploadJob = async(req, res)=>{
    let payload = req.body;
    const validated = createJobSchema.safeParse(payload)
    if(!validated.success){
        return res.status(400).json(JSON.parse(validated.error.message));
    }
    const data = validated.data
    const job = await createJobService(data);
    return res.json(job);
}