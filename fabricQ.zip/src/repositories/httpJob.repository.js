import { pool } from "../config/db.js";

export async function createJob(job) {
  const query = `
    INSERT INTO http_jobs (
      method,
      url,
      body,
      headers,
      schedule_type,
      run_at,
      cron_expression,
      status,
      max_attempts,
      attempts,
      backoff_seconds,
      next_run
    )
    VALUES (
      $1,
      $2, 
      $3, 
      $4, 
      $5,
      CASE WHEN $6::bigint IS NULL THEN NULL ELSE to_timestamp($6::bigint) END,
      $7, 
      $8,  
      $9, 
      $10, 
      $11,
      to_timestamp($12::bigint)
 )
    RETURNING *;
  `;

  const values = [
    job.method,
    job.url,
    job.body ?? {},
    job.headers ?? {},
    job.schedule_type,
    job.run_at ?? null,
    job.cron_expression ?? null,
    job.status,
    job.max_attempts,
    job.attempts,
    job.backoff_seconds,
    job.next_run,
  ];

  const { rows } = await pool.query(query, values);
  return rows[0];
}

export async function claimDueJobs(client, limit = 100) {
  const { rows } = await client.query(
    `
    UPDATE http_jobs
    SET locked_at = now()
    WHERE job_id IN (
      SELECT job_id
      FROM http_jobs
      WHERE status = 'PENDING'
        AND next_run <= now()
        AND (locked_at IS NULL OR locked_at < now() - interval '1 minute')
      ORDER BY next_run
      LIMIT $1
      FOR UPDATE SKIP LOCKED
    )
    RETURNING *;
    `,
    [limit]
  );
  return rows;
}
 
// Called after an execution row has been created for a job.
// - CRON jobs: advance next_run to the next cron occurrence, unlock, stay PENDING.
// - ONCE jobs: no more runs due; unlock and flip to a terminal-ish state.
//   (Terminal status here just means "not due again" - the execution's
//   own status is what tracks success/failure of the actual HTTP call.)
export async function markJobScheduled(client, jobId, { nextRun, isRecurring }) {
  if (isRecurring) {
    await client.query(
      `UPDATE http_jobs
       SET next_run = to_timestamp($2::bigint), locked_at = NULL, updated_at = now()
       WHERE job_id = $1`,
      [jobId, nextRun]
    );
  } else {
    await client.query(
      `UPDATE http_jobs
       SET status = 'RUNNING', locked_at = NULL, updated_at = now()
       WHERE job_id = $1`,
      [jobId]
    );
  }
}
 
// Worker calls this once it knows the outcome of a ONCE job's single execution,
// or a CRON job run that has exhausted its retries for this occurrence.
export async function finalizeJobRun(client, jobId, { success, isRecurring }) {
  if (isRecurring) {
    // recurring jobs go back to PENDING regardless of outcome - they'll fire again
    await client.query(
      `UPDATE http_jobs SET status = 'PENDING', updated_at = now() WHERE job_id = $1`,
      [jobId]
    );
  } else {
    await client.query(
      `UPDATE http_jobs SET status = $2, updated_at = now() WHERE job_id = $1`,
      [jobId, success ? "COMPLETED" : "FAILED"]
    );
  }
}
 
export async function incrementAttempts(client, jobId) {
  await client.query(
    `UPDATE http_jobs SET attempts = attempts + 1, updated_at = now() WHERE job_id = $1`,
    [jobId]
  );
}
 
export async function getJobById(client, jobId) {
  const { rows } = await client.query(
    `SELECT * FROM http_jobs WHERE job_id = $1`,
    [jobId]
  );
  return rows[0] ?? null;
}